import pymysql
# 导入模块
def select_db(sql):
    conn = pymysql.connect(host="154.211.15.15", user="hhj", password="123456", database="kyzs",port=3306)
    # conn:创建连接对象
    # host：连接的mysql主机 本机是127.0.0.1
    # port:连接的mysql主机的端口，默认是3306
    # database:数据库的名称
    # user：连接的用户名
    # password：连接的密码
    curs = conn.cursor()
    # 通过连接获取游标 返回cursor对象，用于执行sql语句并获得结果
    curs.execute(sql)
    # 使用游标执行SQL语句
    rows = curs.fetchall()
    # 执行查询时，获取结果集的所有行
    curs.close()
    # 关闭游标
    conn.close()
    # 关闭连接
    return rows

def exeu_db(sql):
    conn = pymysql.connect(host="154.211.15.15", user="hhj", password="123456", database="kyzs",port=3306)
    curs = conn.cursor()
    curs.execute(sql)
    # 使用游标执行SQL语句
    conn.commit()
    # 提交数据
    curs.close()
    conn.close()
if __name__ == '__main__':
    pass