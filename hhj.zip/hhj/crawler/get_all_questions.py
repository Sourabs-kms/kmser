import requests
import time
from lxml import etree
from utils.db_tool import *
import re


def start_up():
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 Edg/92.0.902.67',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'sec-ch-ua': '^\\^Chromium^\\^;v=^\\^92^\\^, ^\\^',
        'sec-ch-ua-mobile': '?0',
        'Upgrade-Insecure-Requests': '1',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Content-Type': 'application/x-www-form-urlencoded',
    }

    response = requests.get('https://kaoyan.eol.cn/e_ky/zt/common/zhenti/', headers=headers)
    # 取标签val中的内容
    finals = re.findall('val="(.*?)"', response.content.decode('utf8'))
    # print(finals)
    list_sum = []
    # print(len(finals))
    num=0
    for url in finals:
        num+=1
        # print(num)
        url = "https://school.kaoyan.cn/share/testpaper/" + url
        # print(url)

        response2 = requests.get(url, headers=headers)
        final = re.findall('pdfurl:"(.*?)"', response2.content.decode('utf8'))
        print(final)
        title = re.findall('title\s=\s"(.*?)"', response2.content.decode('utf8'))
        if len(final) > 0 and len(title) >0:
            list_a=[final[0],title[0]]
            list_sum.append(list_a)
            sql="insert into history values (null ,'{}','{}','原创',now())".format(title[0],final[0])
            exeu_db(sql)
    # print(list_sum)


if __name__ == '__main__':
    start_up()
