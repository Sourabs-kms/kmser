import requests
import time
from lxml import etree
from utils.db_tool import *

def start_up():
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 Edg/92.0.902.67',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'sec-ch-ua': '"Chromium";v="92", " Not A;Brand";v="99", "Microsoft Edge";v="92"',
        'sec-ch-ua-mobile': '?0',
        'Upgrade-Insecure-Requests': '1',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Referer': 'https://juece.kuakao.com/s/fsx-0-0-0-0-0-0-0-0-1.html',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    for i in range(6000,7500):
        try:
            print(i)
            conn = pymysql.connect(host="8.131.63.235", user="root", password="123456", database="kyzs2", port=7004)
            curs = conn.cursor()
            headers['Referer']='https://juece.kuakao.com/s/fsx-0-0-0-0-0-0-0-0-{}.html'.format(i-1)
            url='https://juece.kuakao.com/s/fsx-0-0-0-0-0-0-0-0-{}.html'.format(i)
            response=requests.get(url,headers=headers)
            html=etree.HTML(response.content.decode('utf-8'))

            tables=html.xpath('.//div[@class="record_tabbox_x mt15"]//table/tbody/tr')
            for table in tables:
                texts=table.xpath('./td//text()')
                sql="insert into marks values(null,'{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(
                    texts[0],texts[1],texts[2],texts[3],texts[4],texts[5],texts[6],texts[7],texts[8],texts[9]
                )
                curs.execute(sql)
            conn.commit()
            curs.close()
            conn.close()
        except:
            print("出错"+str(i))

if __name__ == '__main__':
    start_up()