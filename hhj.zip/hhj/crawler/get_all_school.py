import requests
import json
import time
from utils.db_tool import *

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 Edg/92.0.902.67',
    'Connection': 'keep-alive',
    'sec-ch-ua': '^\\^Chromium^\\^;v=^\\^92^\\^, ^\\^',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua-mobile': '?0',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Origin': 'https://school.kaoyan.cn',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://school.kaoyan.cn/web/special/pcfindzy',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
}


def start_run():
    params = (
        ('format', 'json'),
    )

    parrt_data = {
        'act': 'do',
        'keyword': '',
        'recruit_type': '',
        'type': '',
        'root_id': '',
        'pid': '',
        'page': '3'
    }
    for i in range(1, 672):
        parrt_data['page'] = str(i)
        response = requests.post('https://school.kaoyan.cn/web/special/pcfindzy', headers=headers, params=params,
                                 data=parrt_data)
        print("当前是第{}页".format(str(i)))
        try:
            data_json = json.loads(response.text)
            list_sum = data_json['data']['data']
            for item in list_sum:
                print(item)
                sql = 'select * from professional_class where special_id={}'.format(item['special_id'])
                data = select_db(sql)
                if len(data) == 0:
                    sql = "insert into professional_class values (null,'{}','{}','{}','{}','{}','{}','{}')".format(
                        item['lev1'], item['lev1name'], item['lev2'], item['lev2name'], item['lev3'], item['name'],
                        item['special_id'])
                    exeu_db(sql)
                    print(sql)
        except:
            print("当前{}页出错".format(str(i)))


if __name__ == '__main__':
    start_run()
