from flask import Flask
from flask import request
from flask import redirect
from flask import url_for
from flask import render_template
#与静态网页挂钩
from flask import session
from flask import jsonify
from utils.db_tool import *
from pypinyin import lazy_pinyin
#from flaskext.markdown import Markdown
# 初始化app
app = Flask(__name__, static_folder='static', static_url_path='/')
app.config['SECRET_KEY'] = 'wwqwwqwwq'
#Markdown(app)


@app.route('/index', methods=['POST', 'GET'])
@app.route('/', methods=['POST', 'GET'])
def index():
    # 主页转发

    sql = 'select t1.id,t1.title,t1.content,t1.description, t1.headPho,t1.creTime,t1.updTime,t1.views,t2.name from channels t1,types t2 where t1.typeId=t2.id ORDER BY t1.views LIMIT 12'
    # limit检索前12个记录行
    datas = select_db(sql)
    # 数据库查询函数
    # flask与主页挂钩起来
    # 模板渲染后将静态html变为动态网页
    return render_template("index.html", datas=datas)


@app.route('/channel', methods=['POST', 'GET'])
def kaoyanpingdao():
    # 考研频道

    sql = 'SELECT t2.name,count(t1.typeId) FROM channels t1,types t2 where t1.typeId=t2.id GROUP BY t1.typeId'
    datas2 = select_db(sql)
    sql = 'select id,title from channels ORDER BY creTime DESC LIMIT 5'
    datas3 = select_db(sql)
    sql = 'select id,title from channels ORDER BY views DESC LIMIT 5'
    datas4 = select_db(sql)
    datas = []

    page = request.values.get("page")
    text1 = request.values.get("text1")
    # 因前端没输入page 所以page为空
    if not page:
        page = 1
    # 模糊搜索功能
    # 如果存在文章，则在数据库中like 找到
    if text1:
        sql = "select t1.id,t1.title,t1.content,t1.description, t1.headPho,t1.creTime,t1.updTime,t1.views,t2.name from channels t1,types t2 where t1.typeId=t2.id and t1.title LIKE '%{}%' LIMIT {},10".format(
            text1, (int(page) - 1) * 10)
    # 如果什么都不输入，则显示任何文章
    else:
        sql = "select t1.id,t1.title,t1.content,t1.description, t1.headPho,t1.creTime,t1.updTime,t1.views,t2.name from channels t1,types t2 where t1.typeId=t2.id LIMIT {},10".format(
            (int(page) - 1) * 10)
    print(sql)
    datas = select_db(sql)
    sql = 'select count(id) from channels'
    datas5 = select_db(sql)[0][0]
    if datas5 <= 10:
        pageSum = 1
    else:
        pageSum = int(datas5 / 10) + 1

    return render_template("channel.html", datas=datas,
                           msg={"page": str(page), "pageNext": str(int(page) + 1), "pageLast": str(int(page) - 1),
                                'pageSum': str(pageSum), 'sum': len(datas), "typeClass": datas2, "newTitle": datas3,
                                "newTitle2": datas4})


@app.route('/channel/detail/<int:id>', methods=['POST', 'GET'])
def kaoyanpingdao_detail(id):
    sql = 'select t1.id,t1.title,t1.content,t1.description, t1.headPho,t1.creTime,t1.updTime,t1.views,t2.name,t1.flag from channels t1,types t2 where t1.typeId=t2.id and t1.id=' + str(
        id)
    data = select_db(sql)[0]
    print(data)
    sql = 'update channels set views=views+1 where id={}'.format(id)
    exeu_db(sql)
    import markdown
    test_data=markdown.markdown(data[2])
    print(test_data)
    return render_template('channel_detail.html', datas=data,test_data=test_data)


@app.route('/persons', methods=['POST', 'GET'])
def kaoyanrenshu():
    # 考研人数频道索引页
    # 渲染考研人数静态网页
    return render_template("persons.html")


@app.route('/persons/selectsum', methods=['POST', 'GET'])
def kaoyanrenshu_selectSum():
    # 考研总数分析
    # sql语句从表persons_sum里查总数据
    sql = 'select * from persons_sum'
    sum_persons = select_db(sql)

    # 查总的学校 没用到
    # sql2 = 'SELECT school FROM `marks` GROUP BY school'
    # datas2 = [i[0] for i in select_db(sql2)]
    # # 进行一个排序 对首个汉字的拼音顺序进行排序 lambda隐函数，固定写法
    # datas2.sort(key=lambda i: i[0])

    # 查总专业 没用到
    # sql3 = 'select lev1,lev2,lev3,lev3name from professional_class;'
    # now_datas = select_db(sql3)
    # datas3 = []
    # for data in now_datas:
    #     list_a = [(str(data[0]) + str(data[1]) + str(data[2])),
    #               (str(data[0]) + str(data[1]) + str(data[2]) + data[3])]
    #     # append相当于尾插 把a列表插入在datas3后面
    #     datas3.append(list_a)
    # datas3.sort()
    # print(datas3)
    # print(sum_persons)

    new_sum_persons = []
    for sum_person in sum_persons:
        sum_person = list(sum_person)
        # 比例 录取人数/报名人数*100
        sum_person.append(int(sum_person[3]) / int(sum_person[2]) * 100)
        new_sum_persons.append(sum_person)
    print(new_sum_persons)
    # 动态渲染返回persons_sum网页
    return render_template("persons_sum.html", sum_persons=new_sum_persons)
# , sum_school=datas2, sum_class=datas3

@app.route('/persons/selectschool', methods=['POST', 'GET'])
def kaoyanrenshu_selectSchool():

    if request.method == 'GET':
        # distinct进行数据唯一化 通过marks表把所有学校查询出来
        sql = 'select distinct school from marks'
        datas = select_db(sql)
        # print(datas)
        # 查到的数据格式不对，需要进行格式转化
        # .strip()函数是去掉空格 进行数据转换
        schools = [i[0].strip() for i in datas]
        # 调用lazy_pinyin函数按照拼音进行排序
        schools.sort(key=lambda i: lazy_pinyin(i[0]))
        # print(schools)
        #  result的返回是前端判断是否启用容器的 False就不启动
        return render_template("persons_school.html", schools=schools, result=False)
    # post请求
    else:

        school = request.form.get("school")

        department = request.form.get("department")

        classes = request.form.get("classes")

        sql = "select * from marks where school='{}' and professional='{}' and department='{}' order by year".format(
            school, classes,department)
        datas = select_db(sql)
        print(datas)

        return render_template("persons_school.html", datas=datas,
                               info={'school': school, "department": department, "classes": classes}, result=True)


@app.route('/persons/selectclasses', methods=['POST', 'GET'])
def kaoyanrenshu_selectClasses():
    # 考研专业分析
    if request.method == 'GET':
        sql = 'select distinct professional from marks'
        datas = select_db(sql)
        professionals = [i[0].strip() for i in datas]
        professionals.sort(key=lambda i: lazy_pinyin(i[0]))
        print(professionals)
        return render_template("persons_classes.html", professionals=professionals, result=False)
    else:
        school = request.form.get("school")
        department = request.form.get("department")
        classes = request.form.get("classes")
        sql = "select * from marks where school='{}' and professional='{}' and department='{}' order by year".format(
            school, classes,department)
        datas = select_db(sql)
        print(datas)
        return render_template("persons_classes.html", datas=datas,
                               info={'school': school, "department": department, "classes": classes}, result=True)


@app.route('/persons/selectschooldb', methods=['POST', 'GET'])
def kaoyanrenshu_selectSchooldb():
    # 考研学校对比图表分析
    if request.method == 'GET':
        sql = 'select distinct school from marks'
        datas = select_db(sql)
        schools = [i[0] for i in datas]
        schools.sort(key=lambda i: lazy_pinyin(i[0]))
        print(schools)
        return render_template("persons_school_db.html", schools=schools, result=False)
    # post
    else:
        school = request.form.get("school")
        school2 = request.form.get("school2")
        department = request.form.get("department")
        classes = request.form.get("classes")
        sql = "select * from marks where school='{}' and professional='{}' and department='{}' order by year".format(
            school, classes,
            department)
        datas1 = select_db(sql)
        sql = "select * from marks where school='{}' and professional='{}' and department='{}' order by year".format(
            school2, classes,
            department)
        datas2 = select_db(sql)
        print(datas1)
        print(datas2)
        datas1_1 = [i[1] for i in datas1]
        datas2_1 = [i[1] for i in datas2]
        # set() 函数创建一个无序不重复元素集
        years = list(set(datas1_1) & set(datas2_1))
        years.sort()
        print(years)
        dict_1 = {"school": school}
        dict_2 = {"school": school2}
        datas1 = list(datas1)
        datas2 = list(datas2)
        datas1.sort(key=lambda i: i[1])
        datas2.sort(key=lambda i: i[1])
        for data in datas1:
            if data[1] in years:
                dict_1[data[1]] = data
        for data in datas2:
            if data[1] in years:
                dict_2[data[1]] = data
        print(dict_1)
        print(dict_2)

        return render_template("persons_school_db.html", years=years, dict_1=dict_1, dict_2=dict_2, datas=datas1,
                               info={'school': school, "department": department, "classes": classes}, result=True)


@app.route('/persons/api/getclass', methods=['POST', 'GET'])
def kaoyanrenshu_getClass_api():
    # 获取前端传过来的school和department
    school = request.values.get('school')
    department = request.values.get('department')
    # 从数据库中唯一化查询专业
    sql = "select distinct professional from marks where school='{}' and department='{}'".format(school, department)
    datas = select_db(sql)
    classes = [i[0] for i in datas]
    classes.sort(key=lambda i: lazy_pinyin(i[0]))
    print(classes)
    return jsonify({"datas": classes})


@app.route('/persons/api/getdepartment', methods=['POST', 'GET'])
def kaoyanrenshu_getDepartment_api():
    # 获取前端传过来的school
    school = request.values.get('school')
    # 从数据库查询唯一的department
    sql = "select distinct department from marks where school='{}'".format(school)
    datas = select_db(sql)
    departments = [i[0] for i in datas]
    # 对department排序
    departments.sort(key=lambda i: lazy_pinyin(i[0]))
    print(departments)
    # 返回成为一个json数据
    return jsonify({"datas": departments})


@app.route('/persons/api/getdepartment2', methods=['POST', 'GET'])
def kaoyanrenshu_getDepartment_api2():
    school = request.values.get('school')
    classes = request.values.get('classes')
    sql = "select distinct department from marks where school='{}' and professional='{}'".format(school, classes)
    datas = select_db(sql)
    departments = [i[0] for i in datas]
    departments.sort(key=lambda i: lazy_pinyin(i[0]))
    print(departments)
    return jsonify({"datas": departments})


@app.route('/persons/api/getschool', methods=['POST', 'GET'])
def kaoyanrenshu_getSchool_api():
    classes = request.values.get('classes')
    sql = "select distinct school from marks where professional='{}'".format(classes)
    datas = select_db(sql)
    schools = [i[0] for i in datas]
    schools.sort(key=lambda i: lazy_pinyin(i[0]))
    print(schools)
    return jsonify({"datas": schools})


@app.route('/persons/api/getschool2', methods=['POST', 'GET'])
def kaoyanrenshu_getSchool_api2():
    classes = request.values.get('classes')
    department = request.values.get('department')
    school = request.values.get('school')
    print(classes)
    sql = "select distinct school from marks where professional='{}' and department='{}' and school!='{}'".format(
        classes, department, school)
    print(sql)
    datas = select_db(sql)
    schools = [i[0] for i in datas]
    schools.sort(key=lambda i: lazy_pinyin(i[0]))
    print(schools)
    return jsonify({"datas": schools})


@app.route('/historys', methods=['POST', 'GET'])
def linianfenshu():
    # 历年真题
    sql = 'select * from history'
    datas = select_db(sql)
    return render_template("historys.html", datas=datas, sum=len(datas))


@app.route('/history/<int:id>', methods=['POST', 'GET'])
def linianfenshu_detail(id):
    sql = 'select * from history where id={}'.format(id)
    data = select_db(sql)[0]
    return render_template("history_detail.html", data=data)


@app.route('/tel', methods=['POST', 'GET'])
def yanzhaoban():
    # 研招办联系方式
    sql = 'select * from tel'
    datas = select_db(sql)
    return render_template("yanzhaoban.html", datas=datas, sum=len(datas))


@app.route('/teldetail/<int:id>', methods=['POST', 'GET'])
def yanzhaoban_detail(id):
    # 研招办联系方式
    sql = 'select * from tel where id={}'.format(id)
    data = select_db(sql)[0]
    print(data)
    return render_template("yanzhaoban2.html", data=data)


@app.route('/admin/login', methods=['POST', 'GET'])
def admin_login():
    # 用户登录
    if request.method == 'GET':
    # 如果请求方法是get请求
        if session.get('user'):
            # session.get()
            # 这种方式总是会去数据库查询数据并返回一个真实的对象,该对象就代表数据库中的一行而非代理。
            return redirect('/admin/index')
        else:
            return render_template("admin/login.html")
    else:
    # 如果请求方法是post请求
        username = request.form.get("username")
        password = request.form.get("password")
        sql = "select * from admin where username='{}' and password='{}'".format(username, password)
        print(sql)
        result = select_db(sql)
        print(result)
        if len(result) > 0:
            # 如果有结果 则跳转至后台主页面
            # 直接使用session对存储的内容赋值
            session['user'] = 'admin'
            return redirect('/admin/index')
        else:
            # 如果没有结果 则提示登陆失败
            return render_template('admin/login.html', mgr="用户名或密码错误！登录失败。")


@app.route('/admin/logout', methods=['POST', 'GET'])
def admin_logout():
    if session.get('user'):
        session.pop('user')
    return redirect('/admin/login')


@app.route('/admin', methods=['POST', 'GET'])
@app.route('/admin/index', methods=['POST', 'GET'])
def admin_index():
    if request.method == 'GET':
        if session.get('user'):

            sql = 'select t1.id,t1.title,t1.content,t1.description, t1.headPho,t1.creTime,t1.updTime,t1.views,t2.name from channels t1,types t2 where t1.typeId=t2.id;'
            datas = select_db(sql)
            return render_template("/admin/index.html", footer={'sum': len(datas)}, datas=datas)
        else:
            return redirect("/admin/login")


@app.route('/admin/index/add', methods=['POST', 'GET'])
def admin_index_add():
    if request.method == 'GET':
        sql = 'select id,name from types'
        types = select_db(sql)
        return render_template("admin/index-input.html", datas={"types": types},text_data=[])
    else:
        flag = request.form.get('flag')
        title = request.form.get('title')
        type_id = request.form.get('type.id')
        pic_url = request.form.get('firstPicture')
        content = request.form.get('content')
        description = request.form.get('description')
        sql = "insert into channels values(null,'{}','{}','{}','{}',now(),now(),1,{},'{}')".format(title, content,
                                                                                                   description,
                                                                                                   pic_url, type_id,
                                                                                                   flag)
        exeu_db(sql)
        print(flag, title, type_id, pic_url, content, description)
        return redirect('/admin/index')


@app.route('/admin/index/edit/<int:id>', methods=['POST', 'GET'])
def admin_index_edit(id):
    if request.method == 'GET':
        sql = 'select id,name from types'
        types = select_db(sql)
        sql = 'select * from channels where id={}'.format(id)
        data = select_db(sql)[0]
        return render_template("admin/index-input.html", datas={"types": types}, text_data=data, id=id)
    else:
        id = request.form.get('id')
        flag = request.form.get('flag')
        title = request.form.get('title')
        type_id = request.form.get('type.id')
        pic_url = request.form.get('firstPicture')
        content = request.form.get('content')
        description = request.form.get('description')
        sql = "update channels set flag='{}',title='{}',content='{}',description='{}',headPho='{}',updTime=now(),typeId='{}' where id={}".format(
            flag, title, content, description, pic_url, type_id, id)
        print(sql)
        exeu_db(sql)
        # print(flag, title, type_id, pic_url, content, description)
        return redirect('/admin/index')


@app.route('/admin/index/delete', methods=['POST', 'GET'])
def admin_index_delete():
    id = request.values.get('id')
    sql = 'delete from channels where id={}'.format(id)
    exeu_db(sql)
    return redirect('/admin/index')


@app.route('/admin/types', methods=['POST', 'GET'])
def admin_types():
    sql = 'select * from types'
    datas = select_db(sql)
    print(datas)
    return render_template("admin/types.html", datas=datas)


@app.route('/admin/types/add', methods=['POST', 'GET'])
def admin_types_add():
    if request.method == 'GET':
        return render_template("admin/types-input.html")
    else:
        try:
            type = request.form.get("type")
            sql = "insert into types values (null,'{}',now(),now())".format(type)
            exeu_db(sql)
            return redirect('/admin/types')
        except:
            return render_template("admin/types-input.html", msg="错误！！")


@app.route('/admin/types/delete', methods=['POST', 'GET'])
def admin_types_delete():
    id = request.values.get("id")
    sql = 'delete from types where id={}'.format(id)
    exeu_db(sql)
    return render_template("admin/types.html", msg="删除成功！！！")


@app.route('/admin/types/update', methods=['POST', 'GET'])
def admin_types_update():
    if request.method == 'GET':
        id = request.values.get("id")
        sql = 'select name from types where id={}'.format(id)
        datas = select_db(sql)
        print(datas)
        return render_template("admin/types-input.html", data_=datas[0][0])
    else:
        types = request.form.get('type')
        id = request.values.get('id')
        sql = "update types set name='{}' where id={}".format(types, id)
        exeu_db(sql)
        return render_template('admin/types.html', msg="成功！！！")


@app.route('/admin/historys', methods=['POST', 'GET'])
def admin_historys():
    sql = 'select * from history'
    datas = select_db(sql)
    print(datas)
    return render_template("admin/historys.html", datas=datas)


@app.route('/admin/historys/add', methods=['POST', 'GET'])
def admin_historys_add():
    if request.method == 'GET':
        return render_template("admin/history-input.html",data=["","",""])
    else:
        try:
            flag = request.form.get("flag")
            title = request.form.get('title')
            content = request.form.get('content')
            sql = "insert into history values (null,'{}','{}','{}',now())".format(title, content, flag)
            print(sql)
            exeu_db(sql)
            return redirect('/admin/historys')
        except:
            return render_template("admin/history-input.html", msg="错误！！")


@app.route('/admin/historys/edit/<int:id>', methods=['POST', 'GET'])
def admin_historys_edit(id):
    if request.method == 'GET':
        sql = 'select * from history where id={}'.format(id)
        data = select_db(sql)[0]

        return render_template("admin/history-input.html", data=data, id=id)
    else:
        try:
            id = request.form.get("id")
            flag = request.form.get("flag")
            title = request.form.get('title')
            content = request.form.get('content')
            sql = "update history set title='{}',text='{}',type='{}' where id={}".format(title, content, flag, id)
            print(sql)
            exeu_db(sql)
            #返回一个重定向到指定的 URL 的 Response
            return redirect('/admin/historys')
        except:
            return render_template("admin/history-input.html", msg="错误！！")


@app.route('/admin/historys/delete', methods=['POST', 'GET'])
def admin_historys_delete():
    id = request.values.get("id")
    sql = 'delete from history where id={}'.format(id)
    exeu_db(sql)
    return render_template("admin/historys.html", msg="删除成功！！！")


@app.route('/admin/tel', methods=['POST', 'GET'])
def admin_tel():
    sql = 'select * from tel'
    datas = select_db(sql)
    print(datas)
    return render_template("admin/tel.html", datas=datas)


@app.route('/admin/tel/add', methods=['POST', 'GET'])
def admin_tel_add():
    if request.method == 'GET':
        return render_template("admin/tel-input.html",data=["","",""])
    else:
        try:
            title = request.form.get('title')
            content = request.form.get('content')
            sql = "insert into tel values (null,'{}','{}',now())".format(title, content)
            exeu_db(sql)
            return redirect('/admin/tel')
        except:
            return render_template("admin/tel-input.html", msg="错误！！")


@app.route('/admin/tel/edit/<int:id>', methods=['POST', 'GET'])
def admin_tel_edit(id):
    if request.method == 'GET':
        sql = 'select * from tel where id={}'.format(id)
        print(sql)
        data = select_db(sql)[0]
        return render_template("admin/tel-input.html", data=data, id=id)
    else:
        try:
            id = request.form.get('id')
            title = request.form.get('title')
            content = request.form.get('content')
            sql = "update tel set title='{}',text='{}' where id={}".format(title, content, id)
            exeu_db(sql)
            return redirect('/admin/tel')
        except:
            return render_template("admin/tel-input.html", msg="错误！！")


@app.route('/admin/tel/delete', methods=['POST', 'GET'])
def admin_tel_delete():
    id = request.values.get("id")
    sql = 'delete from tel where id={}'.format(id)
    exeu_db(sql)
    return render_template("admin/tel.html", msg="删除成功！！！")

@app.route('/ditu')
def ditu():
    return render_template("ditu.html")

if __name__ == '__main__':
    app.run(debug=True, port=5001)
