import pymysql

def select_db(sql):
    conn = pymysql.connect(host="154.211.15.15", user="zyl", password="123456", database="lagou",port=3306)
    curs = conn.cursor()
    curs.execute(sql)
    rows = curs.fetchall()
    curs.close()
    conn.close()
    return rows

def exeu_db(sql):
    conn = pymysql.connect(host="154.211.15.15", user="zyl", password="123456", database="lagou",port=3306)
    curs = conn.cursor()
    curs.execute(sql)
    conn.commit()
    curs.close()
    conn.close()
if __name__ == '__main__':
    pass