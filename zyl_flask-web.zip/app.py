from flask import Flask,render_template,url_for,render_template,request,session,redirect,url_for
import pymysql
import jieba
from utils import *
import pandas as pd
app = Flask(__name__)
app.config['DEBUG'] = True
app.secret_key = 'zylkms'
    
@app.route('/',methods=['POST', 'GET'])
def logins():
    if request.method == 'GET':
        if session.get('user'):
            return redirect('/index')
        else:
            return render_template("pages-login.html")
    username = request.form.get("username")
    password = request.form.get("password")
    print(username,password)
    sql = "select * from admin where username='{}' and password='{}'".format(username, password)
    print(sql)
    result = select_db(sql)
    print(result)
    if len(result) > 0:
        session['user'] = 'admin'
        return redirect('/index')
    else:
        return render_template('pages-login.html', mgr="用户名或密码错误！请重新输入！")

@app.route('/loginout', methods=['POST', 'GET'])
def admin_logout():
    if session.get('user'):
        session.pop('user')
    return redirect('/')


@app.route('/feedback')
def feedback():
    if session.get('user'):
        datalist = []
        sql = "select * from opinion"
        result = select_db(sql)
        for item in result:
            datalist.append(item)
        return render_template('feedback.html',data = datalist)
    else:
        return redirect("/")




@app.route('/tables/<yyds>')

def hello_wo(yyds):
    if session.get('user'):
        if yyds=='index':
            url_for('index')
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        datalist = []
        sql =f"select * from {yyds}"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        for item in user:
            datalist.append(item)
        conn.close()
        cursor.close()
        return render_template('tables.html',data = datalist)
    else:
        return redirect("/")

@app.route('/index')
def idx():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456' ,
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()

        sqljava = "select count(*) from java"
        data_all = cursor.execute(sqljava)
        sumjava = cursor.fetchall()

        sqlckf = "select count(*) as ds from ckf"
        data_all = cursor.execute(sqlckf)
        sumckf = cursor.fetchall()

        sqlpy = "select count(*) as ds from python"
        data_all = cursor.execute(sqlpy)
        sumpy = cursor.fetchall()

        sqltest = "select count(*) as ds from test"
        data_all = cursor.execute(sqltest)
        sumtest = cursor.fetchall()

        sqlweb = "select count(*) as ds from web"
        data_all = cursor.execute(sqlweb)
        sumweb = cursor.fetchall()

        sqldata = "select count(*) as ds from data_analysis"
        data_all = cursor.execute(sqldata)
        sumdata = cursor.fetchall()

        datasum = [sumjava[0][0],sumckf[0][0],sumpy[0][0],sumtest[0][0],sumweb[0][0],sumdata[0][0]]
        print('数据总量',datasum)

        print(sum(datasum))
        return render_template('index.html',datasum=datasum,data = sum(datasum))
    else:
        return redirect("/")




@app.route('/c++')
def datacz():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        score = []
        num = []

        sql = "select education,count(education) from ckf group by education"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        print(user)
        for item in user:
            score.append(str(item[0]))
            num.append(item[1])

        score1 = []
        num1 = []
        sql1 = "select exp,count(exp) from ckf group by exp"
        data1 = cursor.execute(sql1)
        user1 = cursor.fetchall()
        print(user1)
        for item in user1:
            score1.append(str(item[0]))
            num1.append(item[1])

        score2 = []
        num2 = []
        sql2 = "select finance,count(finance) from ckf group by finance"  # 融资情况
        data2 = cursor.execute(sql2)
        user2 = cursor.fetchall()
        print(user2)
        datackf = []
        for item in user2:
            datackf.append(item)
        print("data2:", datackf)
        score3 = []
        num3 = []
        sql3 = "select scale,count(scale) from ckf group by scale"
        data3 = cursor.execute(sql3)
        user3 = cursor.fetchall()
        print(user3)
        for item in user3:
            score3.append(str(item[0]))
            num3.append(item[1])

        datalistxx = []
        sql5 = "select SUBSTR(city from 1 for 2),count(city) from ckf group by SUBSTR(city from 1 for 2)"
        datax = cursor.execute(sql5)
        user = cursor.fetchall()
        for item in user:
            datalistxx.append(item)
        print(datalistxx)

        sql6 = "select * from ckf"
        df = pd.read_sql(sql6, conn)
        dom22 = []
        for i in df['education']:
            if i in dom22:
                continue
            else:
                dom22.append(i)
        dom = df[['education', 'salary_range']]
        data = [[], [], [], [], []]
        dom1, dom2, dom3, dom4, dom5 = data
        for i, j in zip(dom['education'], dom['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            # print(i)
            if i in ['不限']:
                dom1.append(j)
            elif i in ['大专']:
                dom2.append(j)
            elif i in ['本科']:
                dom3.append(j)
            elif i in ['硕士']:
                dom4.append(j)
            else:
                dom5.append(j)
        buxian = round(sum(dom1) / len(dom1), 0)
        dazhuan = round(sum(dom2) / len(dom2), 0)
        benke = round(sum(dom3) / len(dom3), 0)
        shuoshi = round(sum(dom4) / len(dom4), 0)
        yingjie = round(sum(dom5) / len(dom5), 0)
        salary = [buxian, dazhuan, benke, shuoshi, yingjie]
        print('薪资:', salary)

        domx = df[['exp', 'salary_range']]
        data_exp = [[], [], [], [], [], [], []]
        domx1, domx2, domx3, domx4, domx5, domx6, domx7 = data_exp
        for i, j in zip(domx['exp'], domx['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            if i in ['经验不限']:
                domx1.append(j)
            elif i in ['经验在校']:
                domx2.append(j)
            elif i in ['经验1年以下']:
                domx3.append(j)
            elif i in ['经验1-3年']:
                domx4.append(j)
            elif i in ['经验3-5年']:
                domx5.append(j)
            elif i in ['经验5-10年']:
                domx6.append(j)
            else:
                domx7.append(j)
        data_explist = ['经验不限', '应届生', '1年以下', '1-3年', '3-5年', '5-10年', '10年以上']

        data_exp_end = []
        for item in data_exp:
            data_exp_end.append(round(sum(item) / len(item), 0))
        print('学历经验薪资', data_exp_end)
        return render_template('c++.html',
                               score=score,
                               num=num,
                               salary=salary,
                               score1=score1,
                               num1=num1,
                               datas=datackf,
                               score3=score3,
                               num3=num3,
                               datalist=datalistxx,
                               data_exp=data_explist,
                               data_exp_end=data_exp_end
                               )

    else:
        return redirect("/")



@app.route('/web')
def web():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        score = []
        num = []
        sql = "select education,count(education) from web group by education"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        print(user)
        for item in user:
            score.append(str(item[0]))
            num.append(item[1])

        score1 = []
        num1 = []
        sql1 = "select exp,count(exp) from web group by exp"
        data1 = cursor.execute(sql1)
        user1 = cursor.fetchall()
        print(user1)
        for item in user1:
            score1.append(str(item[0]))
            num1.append(item[1])

        score2 = []
        num2 = []
        sql2 = "select finance,count(finance) from web group by finance"  # 融资情况
        data2 = cursor.execute(sql2)
        user2 = cursor.fetchall()
        print(user2)
        dataweb = []
        for item in user2:
            dataweb.append(item)
        print("data2:", dataweb)
        score3 = []
        num3 = []
        sql3 = "select scale,count(scale) from web group by scale"
        data3 = cursor.execute(sql3)
        user3 = cursor.fetchall()
        print(user3)
        for item in user3:
            score3.append(str(item[0]))
            num3.append(item[1])

        datalistxx = []
        sql5 = "select SUBSTR(city from 1 for 2),count(city) from web group by SUBSTR(city from 1 for 2)"
        datax = cursor.execute(sql5)
        user = cursor.fetchall()
        for item in user:
            datalistxx.append(item)
        print(datalistxx)

        sql6 = "select * from web"
        df = pd.read_sql(sql6, conn)
        dom22 = []
        for i in df['education']:
            if i in dom22:
                continue
            else:
                dom22.append(i)
        dom = df[['education', 'salary_range']]
        data = [[], [], [], [], []]
        dom1, dom2, dom3, dom4, dom5 = data
        for i, j in zip(dom['education'], dom['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            # print(i)
            if i in ['不限']:
                dom1.append(j)
            elif i in ['大专']:
                dom2.append(j)
            elif i in ['本科']:
                dom3.append(j)
            elif i in ['硕士']:
                dom4.append(j)
            else:
                dom5.append(j)
        buxian = round(sum(dom1) / len(dom1), 0)
        dazhuan = round(sum(dom2) / len(dom2), 0)
        benke = round(sum(dom3) / len(dom3), 0)
        shuoshi = round(sum(dom4) / len(dom4), 0)
        yingjie = round(sum(dom5) / len(dom5), 0)
        salary = [buxian, dazhuan, benke, shuoshi, yingjie]
        print('薪资:', salary)

        domx = df[['exp', 'salary_range']]
        data_exp = [[], [], [], [], [], []]
        domx1, domx2, domx3, domx4, domx5, domx6 = data_exp
        for i, j in zip(domx['exp'], domx['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            if i in ['经验不限']:
                domx1.append(j)
            elif i in ['经验在校']:
                domx2.append(j)
            elif i in ['经验1年以下']:
                domx3.append(j)
            elif i in ['经验1-3年']:
                domx4.append(j)
            elif i in ['经验3-5年']:
                domx5.append(j)
            elif i in ['经验5-10年']:
                domx6.append(j)

        data_explist = ['经验不限', '应届生', '1年以下', '1-3年', '3-5年', '5-10年']

        data_exp_end = []

        for item in data_exp:
            data_exp_end.append(round(sum(item) / len(item), 0))
        print('学历经验薪资', data_exp_end)
        return render_template('web.html',
                               score=score,
                               num=num,
                               salary=salary,
                               score1=score1,
                               num1=num1,
                               datas=dataweb,
                               score3=score3,
                               num3=num3,
                               datalist=datalistxx,
                               data_exp=data_explist,
                               data_exp_end=data_exp_end
                               )
    else:
        return redirect("/")
@app.route('/test')
def test():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        score = []
        num = []

        sql = "select education,count(education) from test group by education"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        print(user)
        for item in user:
            score.append(str(item[0]))
            num.append(item[1])

        score1 = []
        num1 = []
        sql1 = "select exp,count(exp) from test group by exp"
        data1 = cursor.execute(sql1)
        user1 = cursor.fetchall()
        print(user1)
        for item in user1:
            score1.append(str(item[0]))
            num1.append(item[1])

        score2 = []
        num2 = []
        sql2 = "select finance,count(finance) from test group by finance"  # 融资情况
        data2 = cursor.execute(sql2)
        user2 = cursor.fetchall()
        print(user2)
        datatest = []
        for item in user2:
            datatest.append(item)
        print("data2:", datatest)
        score3 = []
        num3 = []
        sql3 = "select scale,count(scale) from test group by scale"
        data3 = cursor.execute(sql3)
        user3 = cursor.fetchall()
        print(user3)
        for item in user3:
            score3.append(str(item[0]))
            num3.append(item[1])

        datalistxx = []
        sql5 = "select SUBSTR(city from 1 for 2),count(city) from test group by SUBSTR(city from 1 for 2)"
        datax = cursor.execute(sql5)
        user = cursor.fetchall()
        for item in user:
            datalistxx.append(item)
        print(datalistxx)

        sql6 = "select * from test"
        df = pd.read_sql(sql6, conn)
        dom22 = []
        for i in df['education']:
            if i in dom22:
                continue
            else:
                dom22.append(i)
        dom = df[['education', 'salary_range']]
        data = [[], [], [], [], []]
        dom1, dom2, dom3, dom4, dom5 = data
        for i, j in zip(dom['education'], dom['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            # print(i)
            if i in ['不限']:
                dom1.append(j)
            elif i in ['大专']:
                dom2.append(j)
            elif i in ['本科']:
                dom3.append(j)
            elif i in ['硕士']:
                dom4.append(j)
            else:
                dom5.append(j)
        buxian = round(sum(dom1) / len(dom1), 0)
        dazhuan = round(sum(dom2) / len(dom2), 0)
        benke = round(sum(dom3) / len(dom3), 0)
        shuoshi = round(sum(dom4) / len(dom4), 0)
        yingjie = round(sum(dom5) / len(dom5), 0)
        salary = [buxian, dazhuan, benke, shuoshi, yingjie]
        print('薪资:', salary)

        domx = df[['exp', 'salary_range']]
        data_exp = [[], [], [], [], [], [], []]
        domx1, domx2, domx3, domx4, domx5, domx6, domx7 = data_exp
        for i, j in zip(domx['exp'], domx['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            if i in ['经验不限']:
                domx1.append(j)
            elif i in ['经验在校']:
                domx2.append(j)
            elif i in ['经验1年以下']:
                domx3.append(j)
            elif i in ['经验1-3年']:
                domx4.append(j)
            elif i in ['经验3-5年']:
                domx5.append(j)
            elif i in ['经验5-10年']:
                domx6.append(j)
            else:
                domx7.append(j)
        data_explist = ['经验不限', '应届生', '1年以下', '1-3年', '3-5年', '5-10年', '10年以上']

        data_exp_end = []
        for item in data_exp:
            data_exp_end.append(round(sum(item) / len(item), 0))
        print('学历经验薪资', data_exp_end)
        return render_template('test.html',
                               score=score,
                               num=num,
                               salary=salary,
                               score1=score1,
                               num1=num1,
                               datas=datatest,
                               score3=score3,
                               num3=num3,
                               datalist=datalistxx,
                               data_exp=data_explist,
                               data_exp_end=data_exp_end
                               )
    else:
        return redirect("/")

@app.route('/python')
def python():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        score = []
        num = []

        sql = "select education,count(education) from python group by education"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        print(user)
        for item in user:
            score.append(str(item[0]))
            num.append(item[1])

        score1 = []
        num1 = []
        sql1 = "select exp,count(exp) from python group by exp"
        data1 = cursor.execute(sql1)
        user1 = cursor.fetchall()
        print(user1)
        for item in user1:
            score1.append(str(item[0]))
            num1.append(item[1])

        score2 = []
        num2 = []
        sql2 = "select finance,count(finance) from python group by finance"#融资情况
        data2 = cursor.execute(sql2)
        user2 = cursor.fetchall()
        print(user2)
        datapython = []
        for item in user2:
           datapython.append(item)
        print("data2:",datapython)
        score3 = []
        num3 = []
        sql3 = "select scale,count(scale) from python group by scale"
        data3 = cursor.execute(sql3)
        user3 = cursor.fetchall()
        print(user3)
        for item in user3:
            score3.append(str(item[0]))
            num3.append(item[1])

        datalistxx = []
        sql5 = "select SUBSTR(city from 1 for 2),count(city) from python group by SUBSTR(city from 1 for 2)"
        datax = cursor.execute(sql5)
        user = cursor.fetchall()
        for item in user:
            datalistxx.append(item)
        print(datalistxx)


        sql6 = "select * from python"
        df = pd.read_sql(sql6, conn)
        dom22 = []
        for i in df['education']:
            if i in dom22:
                continue
            else:
                dom22.append(i)
        dom = df[['education', 'salary_range']]
        data = [[], [], [], [],[]]
        dom1, dom2, dom3, dom4,dom5 = data
        for i, j in zip(dom['education'], dom['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000

            if i in ['不限']:
                dom1.append(j)
            elif i in ['大专']:
                dom2.append(j)
            elif i in ['本科']:
                dom3.append(j)
            elif i in ['硕士']:
                dom4.append(j)
            else:
                dom5.append(j)
        buxian = round(sum(dom1) / len(dom1),0)
        dazhuan = round(sum(dom2) / len(dom2),0)
        benke = round(sum(dom3) / len(dom3),0)
        shuoshi = round(sum(dom4) / len(dom4),0)
        yingjie = round(sum(dom5) / len(dom5), 0)
        salary = [buxian,dazhuan,benke,shuoshi,yingjie]
        print('薪资:',salary)

        domx = df[['exp', 'salary_range']]
        data_exp = [[], [], [], [], [], [], []]
        domx1, domx2, domx3, domx4, domx5, domx6, domx7 = data_exp
        for i, j in zip(domx['exp'], domx['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            if i in ['经验不限']:
                domx1.append(j)
            elif i in ['经验在校']:
                domx2.append(j)
            elif i in ['经验1年以下']:
                domx3.append(j)
            elif i in ['经验1-3年']:
                domx4.append(j)
            elif i in ['经验3-5年']:
                domx5.append(j)
            elif i in ['经验5-10年']:
                domx6.append(j)
            else:
                domx7.append(j)
        data_explist = ['经验不限','应届生','1年以下','1-3年','3-5年','5-10年','10年以上']

        data_exp_end =[]
        for item in data_exp:
            data_exp_end.append(round(sum(item) / len(item),0))
        print('学历经验薪资', data_exp_end)
        return render_template('python.html',
                               score=score,
                               num=num,
                               salary =salary,
                               score1=score1,
                               num1=num1,
                               datas = datapython,
                               score3=score3,
                               num3=num3,
                               datalist=datalistxx,
                               data_exp = data_explist,
                               data_exp_end = data_exp_end
                               )
    else:
        return redirect("/")

@app.route('/java')
def java():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        score = []
        num = []

        sql = "select education,count(education) from java group by education"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        print(user)
        for item in user:
            score.append(str(item[0]))
            num.append(item[1])

        score1 = []
        num1 = []
        sql1 = "select exp,count(exp) from java group by exp"
        data1 = cursor.execute(sql1)
        user1 = cursor.fetchall()
        print(user1)
        for item in user1:
            score1.append(str(item[0]))
            num1.append(item[1])

        score2 = []
        num2 = []
        sql2 = "select finance,count(finance) from java group by finance"  # 融资情况
        data2 = cursor.execute(sql2)
        user2 = cursor.fetchall()
        print(user2)
        datajava = []
        for item in user2:
            datajava.append(item)
        print("data2:", datajava)
        score3 = []
        num3 = []
        sql3 = "select scale,count(scale) from java group by scale"
        data3 = cursor.execute(sql3)
        user3 = cursor.fetchall()
        print(user3)
        for item in user3:
            score3.append(str(item[0]))
            num3.append(item[1])

        datalistxx = []
        sql5 = "select SUBSTR(city from 1 for 2),count(city) from java group by SUBSTR(city from 1 for 2)"
        datax = cursor.execute(sql5)
        user = cursor.fetchall()
        for item in user:
            datalistxx.append(item)
        print(datalistxx)

        sql6 = "select * from java"
        df = pd.read_sql(sql6, conn)
        dom22 = []
        for i in df['education']:
            if i in dom22:
                continue
            else:
                dom22.append(i)
        dom = df[['education', 'salary_range']]
        data = [[], [], [], [], []]
        dom1, dom2, dom3, dom4, dom5 = data
        for i, j in zip(dom['education'], dom['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            # print(i)
            if i in ['不限']:
                dom1.append(j)
            elif i in ['大专']:
                dom2.append(j)
            elif i in ['本科']:
                dom3.append(j)
            elif i in ['硕士']:
                dom4.append(j)
            else:
                dom5.append(j)
        buxian = round(sum(dom1) / len(dom1), 0)
        dazhuan = round(sum(dom2) / len(dom2), 0)
        benke = round(sum(dom3) / len(dom3), 0)
        shuoshi = round(sum(dom4) / len(dom4), 0)
        yingjie = round(sum(dom5) / len(dom5), 0)
        salary = [buxian, dazhuan, benke, shuoshi, yingjie]
        print('薪资:', salary)
        domx = df[['exp', 'salary_range']]
        data_exp = [[], [], [], [], [], [], []]
        domx1, domx2, domx3, domx4, domx5, domx6, domx7 = data_exp
        for i, j in zip(domx['exp'], domx['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            if i in ['经验不限']:
                domx1.append(j)
            elif i in ['经验在校']:
                domx2.append(j)
            elif i in ['经验1年以下']:
                domx3.append(j)
            elif i in ['经验1-3年']:
                domx4.append(j)
            elif i in ['经验3-5年']:
                domx5.append(j)
            elif i in ['经验5-10年']:
                domx6.append(j)
            else:
                domx7.append(j)
        data_explist = ['经验不限', '应届生', '1年以下', '1-3年', '3-5年', '5-10年', '10年以上']

        data_exp_end = []
        for item in data_exp:
            data_exp_end.append(round(sum(item) / len(item), 0))
        return render_template('java.html',
                               score=score,
                               num=num,
                               salary=salary,
                               score1=score1,
                               num1=num1,
                               datas=datajava,
                               score3=score3,
                               num3=num3,
                               datalist=datalistxx,
                               data_exp=data_explist,
                               data_exp_end=data_exp_end
                               )
    else:
        return redirect("/")

def jobx(user):

    text = ""
    for item in user:
        text = text + str(item[0])
    cut = jieba.lcut(text)
    dic = {}
    for word in cut:
        if len(word) != 1:
            dic[word] = dic.get(word, 0) + 1
    wordkey = sorted(dic.items(), key=lambda x: x[1], reverse=True)
    return wordkey

@app.route('/jobword')
def jobword():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        datalist = []
        sql = "select keyword from java"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        job_java = jobx(user)

        sql_c = "select keyword from ckf"
        datas = cursor.execute(sql_c)
        user1 = cursor.fetchall()
        job_ckf = jobx(user1)

        sql_python = "select keyword from python"
        datas = cursor.execute(sql_python)
        user_python = cursor.fetchall()
        job_python = jobx(user_python)

        sql_ui = "select keyword from ui"
        datas = cursor.execute(sql_ui)
        user_ui = cursor.fetchall()
        job_ui = jobx(user_ui)

        sql_web = "select keyword from web"
        datas = cursor.execute(sql_web)
        user_web = cursor.fetchall()
        job_web = jobx(user_web)

        sql_test = "select keyword from test"
        datas = cursor.execute(sql_test)
        user_test = cursor.fetchall()
        job_test = jobx(user_test)
        return render_template('jobword.html',
                               jobword_java = job_java,
                               jobword_ckf = job_ckf,
                               jobword_python = job_python,
                               jobword_ui = job_ui,
                               jobword_web = job_web,
                               jobword_test = job_test
                               )
    else:
        return redirect("/")

@app.route('/welfare')
def welfare():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        datalist = []
        sql = "select company_goodpoints from java"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        text = ""
        for item in user:
            text = text + item[0]

        cut = jieba.lcut(text)
        dic = {}
        for word in cut:
            if len(word) != 1:
                dic[word] = dic.get(word, 0) + 1
        wordlist = sorted(dic.items(), key=lambda x: x[1], reverse=True)
        print('java岗公司福利',wordlist)

        datalist_ckf = []
        sql1 = "select company_goodpoints from ckf"
        data = cursor.execute(sql1)
        ckf = cursor.fetchall()
        text_ckf = ""
        for item in ckf:
            text_ckf = text_ckf + item[0]
        cut_ckf = jieba.lcut(text_ckf)
        dic_ckf = {}
        for word in cut_ckf:
            if len(word) != 1:
                dic_ckf[word] = dic_ckf.get(word, 0) + 1
        datalist_ckf = sorted(dic_ckf.items(), key=lambda x: x[1], reverse=True)
        print('c++岗位公司福利', datalist_ckf)
        return render_template('welfare.html',
                               dic_java=wordlist,
                               dic_ckf=datalist_ckf)
    else:
        return redirect("/")

@app.route('/data_analysis')
def data_analysis():
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        score = []
        num = []

        sql = "select education,count(education) from data_analysis group by education"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        print(user)
        for item in user:
            score.append(str(item[0]))
            num.append(item[1])

        score1 = []
        num1 = []
        sql1 = "select exp,count(exp) from data_analysis group by exp"
        data1 = cursor.execute(sql1)
        user1 = cursor.fetchall()
        print(user1)
        for item in user1:
            score1.append(str(item[0]))
            num1.append(item[1])

        score2 = []
        num2 = []
        sql2 = "select finance,count(finance) from data_analysis group by finance"  # 融资情况
        data2 = cursor.execute(sql2)
        user2 = cursor.fetchall()
        print(user2)
        datadata_analysis = []
        for item in user2:
            datadata_analysis.append(item)
        print("data2:", datadata_analysis)
        score3 = []
        num3 = []
        sql3 = "select scale,count(scale) from data_analysis group by scale"
        data3 = cursor.execute(sql3)
        user3 = cursor.fetchall()
        print(user3)
        for item in user3:
            score3.append(str(item[0]))
            num3.append(item[1])

        datalistxx = []
        sql5 = "select SUBSTR(city from 1 for 2),count(city) from data_analysis group by SUBSTR(city from 1 for 2)"
        datax = cursor.execute(sql5)
        user = cursor.fetchall()
        for item in user:
            datalistxx.append(item)
        print(datalistxx)

        sql6 = "select * from data_analysis"
        df = pd.read_sql(sql6, conn)
        dom22 = []
        for i in df['education']:
            if i in dom22:
                continue
            else:
                dom22.append(i)
        dom = df[['education', 'salary_range']]
        data = [[], [], [], [], []]
        dom1, dom2, dom3, dom4, dom5 = data
        for i, j in zip(dom['education'], dom['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            # print(i)
            if i in ['不限']:
                dom1.append(j)
            elif i in ['大专']:
                dom2.append(j)
            elif i in ['本科']:
                dom3.append(j)
            elif i in ['硕士']:
                dom4.append(j)
            else:
                dom5.append(j)
        buxian = round(sum(dom1) / len(dom1), 0)
        dazhuan = round(sum(dom2) / len(dom2), 0)
        benke = round(sum(dom3) / len(dom3), 0)
        shuoshi = round(sum(dom4) / len(dom4), 0)
        yingjie = round(sum(dom5) / len(dom5), 0)
        salary = [buxian, dazhuan, benke, shuoshi, yingjie]
        print('薪资:', salary)

        domx = df[['exp', 'salary_range']]
        data_exp = [[], [], [], [], [], []]
        domx1, domx2, domx3, domx4, domx5, domx6 = data_exp
        for i, j in zip(domx['exp'], domx['salary_range']):
            j = ((float(j.split('-')[0].replace('k', '').replace('K', '')) + float(
                j.split('-')[1].replace('k', '').replace('K', ''))) / 2) * 1000
            if i in ['经验不限']:
                domx1.append(j)
            elif i in ['经验在校']:
                domx2.append(j)
            elif i in ['经验1年以下']:
                domx3.append(j)
            elif i in ['经验1-3年']:
                domx4.append(j)
            elif i in ['经验3-5年']:
                domx5.append(j)
            elif i in ['经验5-10年']:
                domx6.append(j)

        data_explist = ['经验不限', '应届生', '1年以下', '1-3年', '3-5年', '5-10年']

        data_exp_end = []
        for item in data_exp:
            print('a',item)
            data_exp_end.append(round(sum(item) / len(item), 0))
        print('学历经验薪资', data_exp_end)
        return render_template('data_analysis.html',
                               score=score,
                               num=num,
                               salary=salary,
                               score1=score1,
                               num1=num1,
                               datas=datadata_analysis,
                               score3=score3,
                               num3=num3,
                               datalist=datalistxx,
                               data_exp=data_explist,
                               data_exp_end=data_exp_end
                               )
    else:
        return redirect("/")

@app.route('/ciyun')
def ddd():
    return render_template('ciyuntu.html')


@app.route('/welfare/<kms>')
def welfares(kms):
    if session.get('user'):
        conn = pymysql.connect(host='154.211.15.15',
                               user='zyl',
                               password='123456',
                               port=3306,
                               db='lagou',
                               charset='utf8mb4')
        cursor = conn.cursor()
        datalist = []
        sql = f"select company_goodpoints from {kms}"
        data = cursor.execute(sql)
        user = cursor.fetchall()
        text = ""
        for item in user:
            text = text + item[0]

        cut = jieba.lcut(text)
        dic = {}
        for word in cut:
            print(word)
            if len(word) != 1:
                dic[word] = dic.get(word, 0) + 1
        wordlist = sorted(dic.items(), key=lambda x: x[1], reverse=True)
        # print('java岗公司福利',wordlist)

        datalist_ckf = []
        sql1 = f"select company_goodpoints from {kms}"
        data = cursor.execute(sql1)
        ckf = cursor.fetchall()
        text_ckf = ""
        for item in ckf:
            text_ckf = text_ckf + item[0]
        print(text_ckf)
        cut_ckf = jieba.lcut(text_ckf)
        print(cut_ckf)

        dic_ckf = {}
        for word in cut_ckf:
            if len(word) != 1:
                dic_ckf[word] = dic_ckf.get(word, 0) + 1
        datalist_ckf = sorted(dic_ckf.items(), key=lambda x: x[1], reverse=True)
        print('c++岗位公司福利', datalist_ckf)
        return render_template('welfare.html',
                               dic_java=wordlist,
                               dic_ckf=datalist_ckf)
    else:
        return redirect("/")

if __name__ == '__main__':

   app.run(
        host = '0.0.0.0',
        port = 8866,
        debug = True
    )
